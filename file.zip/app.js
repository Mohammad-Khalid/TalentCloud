var express = require('express');
var bodyParser = require('body-parser');
var session = require('express-session');
var user = require("./routes/user");
var multer = require("multer");
var resultFile = require('./routes/readFile');
var mysql = require('mysql');
//var cors = require()
var port = process.env.port || 3000;
//var auth = require("./routes/auth").auth;
var app = module.exports = express();
app.use(bodyParser.urlencoded({
    extended: false
}));
app.use(bodyParser.json());
app.use(session({
    secret: 'shhhh, very secret'
}));
//app.set('views', __dirname + '/views');
//app.use(express.static(__dirname + '/views'));
app.use(express.static(__dirname + '/public'));
//app.set('view engine', 'ejs')
app.use(multer({
    dest: './public/uploads/',
    rename: function (fieldname, filename) {
        return filename;
    }
}));
app.post("/register", user.register);
app.post("/login", user.login);
app.get('/', function (req, res) {
    res.sendFile('public/registration.html', {
        "root": "."
    });
})
app.get("/showResult", user.showResult);
app.use("/result", resultFile);
//app.get("/", user.getData);


app.use(function (req, res, next) {
    res.status(404).send("NOT FOUND");
});

function restrict(req, res, next) {
    if (req.session.user) {
        next();
    } else {
        // req.session.error = 'Access denied!';
        res.redirect('/');
    }
}

app.listen(port, function (req, res) {
    console.log("Server is running at port "+port);
});